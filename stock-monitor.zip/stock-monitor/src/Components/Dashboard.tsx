import { Card, CardContent, Container, Typography } from '@mui/material';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useAuth } from './AuthContext';

interface Stock {
    symbol: string;
    price: string;
}

const Dashboard: React.FC = () => {
    const { user } = useAuth();
    const [watchlist, setWatchlist] = useState<Stock[]>([]);

    useEffect(() => {
        const fetchWatchlist = async () => {
            if (user) {
                const response = await axios.get(`/api/watchlist/${user.id}`);
                setWatchlist(response.data);
            }
        };
        fetchWatchlist();
    }, [user]);

    return (
        <Container>
            <Typography variant="h4" gutterBottom>
                My Watchlist
            </Typography>
            {watchlist.map(stock => (
                <Card key={stock.symbol}>
                    <CardContent>
                        <Typography variant="h5">{stock.symbol}</Typography>
                        <Typography variant="body2">{stock.price}</Typography>
                    </CardContent>
                </Card>
            ))}
        </Container>
    );
};

export default Dashboard;
